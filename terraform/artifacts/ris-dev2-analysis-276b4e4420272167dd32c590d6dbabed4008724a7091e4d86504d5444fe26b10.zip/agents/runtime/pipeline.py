#!/usr/bin/env python3
"""Worker → Agent Body Runtime-Verdrahtung (Gate 5, unser Bereich).

Verbindet den vorhandenen SQS-/Worker-Eingang mit dem vorhandenen
Agent-Body-Pfad ueber das vorhandene Ecosystem — ohne neues
Queue-/Retry-/DLQ-/Idempotency-System:

  SQS-Record
    -> WorkItem validieren (agents.base, bestehend)
    -> Event -> ProcessingEnvelope (event_hook, bestehend)
    -> Discovery -> Eligibility (ecosystem, bestehend)
    -> Auswahl (ecosystem AgentRouter, bestehend; kein hartcodierter Agent)
    -> Ausfuehrung (ExecutionEngine -> AgentInvoker -> AgentBody, bestehend)
    -> ReferenceAgent.process_work (bestehend)
    -> Result persistieren (Work-Items-Tabelle, bestehend)

Idempotency (bestehende Tabelle, Conditional Write, kein neues System):
  ERSTE Registrierung (workId neu) -> Verarbeitung startet (Attempt 1).
  DUPLIKAT (workId bekannt, COMPLETED) -> kein neuer fachlicher Run.
  FEHLER NACH REGISTRIERUNG (FAILED) -> Redelivery = neuer Attempt
    (attempt+1, neue execution_id, gleicher Processing-Kontext).
  FEHLER VOR REGISTRIERUNG (ungueltiges WorkItem) -> keine Ausfuehrung,
    Exception -> SQS-Redelivery -> bestehende DLQ nach maxReceiveCount.
"""

from __future__ import annotations

import json
import logging
import os
import uuid
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Optional, Tuple

from agents.base import WorkItem
from agents.ecosystem.discovery import AgentDiscovery
from agents.ecosystem.eligibility import EligibilityPipeline
from agents.ecosystem.event_hook import Event, EventHook, ProcessingEnvelope, TriggerType
from agents.ecosystem.health_plane import (
    Component,
    REASON_AGENT_ERROR,
    REASON_ENTITLEMENT_UNAVAILABLE,
)
from agents.ecosystem.registry import (
    AgentDescriptor,
    AgentRegistry,
    AgentStatus,
    ExecutionProfile,
    get_registry,
)
from agents.ecosystem.routing import AgentRouter as EcosystemRouter
from agents.ecosystem.routing import ExecutionEngine
from agents.ecosystem import health_sink
from agents.runtime.subject_fence import (
    SubjectFenceBlocked,
    SubjectFenceUnavailable,
    assert_fence_clear,
    subject_fence_key,
)

logger = logging.getLogger(__name__)

BODY_VERSION = "1.0.0"
RUNTIME_LAMBDA = "python3.14"

REFERENCE_AGENT_ID = "reference_agent"
REFERENCE_CAPABILITY = "reference.echo"
REFERENCE_WORK_TYPE = "agent_reference_agent"

TERMINAL_DUPLICATE_STATES = {"COMPLETED", "CANCELLED", "DEAD_LETTER"}
# Erasure cancellation is a terminal admission decision too.  A queued or
# redelivered message must never turn CANCELLED back into RUNNING.
ERASURE_SUPPRESSED_STATES = {"CANCELLED"}

# Fehlercodes, die einen KONTROLLIERTEN Fehlschlag bedeuten (kein Retry:
# die Nachricht wird konsumiert). Alle anderen Fehlertypen (unerwartete
# Exceptions wie RuntimeError, ClientError, ...) fuehren nach Persistenz
# zu einem Raise, damit SQS erneut zustellt (Retry -> neuer Attempt;
# Begrenzung ueber bestehende DLQ/maxReceiveCount, kein neues System).
PERMANENT_ERROR_CODES = frozenset({
    "VALIDATION_ERROR",
    "ValidationError",
    "NOT_FOUND",
    "ORDER_NOT_FOUND",
    "INVALID_TRANSITION",
    "CONFLICT",
    "POST_UNKNOWN",
})


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def ensure_reference_agent(
    registry: Optional[AgentRegistry] = None,
    body: Any = None,
    analysis_agent: Any = None,
) -> Tuple[AgentRegistry, Any]:
    """ReferenceAgent (+ Orders-Function) in Registry + Body-Router verankern.

    Harness-Muster; kein hartcodierter Agent im Worker: Die Auswahl trifft
    das Ecosystem; hier wird nur registriert, WAS es gibt (Descriptoren +
    Handler). Die Orders-Function delegiert an den OrdersPort (Gate 6).
    """
    from agents.agent_body import AgentBody
    from agents.ats_agent.agent import ATSAgent
    from agents.ats_agent.registry import (
        ATS_ANALYZE_CAPABILITY,
        ATS_WORK_TYPE,
        get_ats_descriptor,
    )
    from agents.orders.function import register_orders_function
    from agents.reference_agent.service import ReferenceAgent

    registry = registry or get_registry()
    if not registry.is_registered(REFERENCE_AGENT_ID):
        registry.register(
            REFERENCE_AGENT_ID,
            AgentDescriptor(
                agent_id=REFERENCE_AGENT_ID,
                name="reference_agent",
                version="1.0.0",
                status=AgentStatus.ACTIVE,
                capabilities=[REFERENCE_CAPABILITY],
                supported_bodies=[BODY_VERSION],
                supported_runtimes=[RUNTIME_LAMBDA],
                execution_profile=ExecutionProfile.LAMBDA,
                risk_level="low",
                description="Technischer Nachweis-Agent (Echo, keine Domain-Logik)",
            ),
        )
    body = body or AgentBody()
    agent = ReferenceAgent()
    body.register_agent(work_type=REFERENCE_WORK_TYPE, handler=agent.process_work)
    body.register_agent(capability=REFERENCE_CAPABILITY, handler=agent.process_work)
    body.register_agent(agent_id=REFERENCE_AGENT_ID, handler=agent.process_work)
    register_orders_function(registry, body)
    # Gate 8: Dummy Agents A/B (DEV/TEST-Nachweis, keine Fachlogik).
    from agents.dummy.agents import register_dummy_agents
    register_dummy_agents(registry, body)
    # Gate 9: JobSearch Domain Agent (persistent, Delegation ans Repository).
    from agents.jobsearch_agent.agent import register_jobsearch_agent
    register_jobsearch_agent(registry, body)
    # Gate 7: ATS als erster echter Domain Agent (Descriptor + Routen aus
    # bestehender Registry-Anbindung; Auswahl bleibt beim Ecosystem).
    if not registry.is_registered("ats-agent"):
        registry.register("ats-agent", get_ats_descriptor())
    ats = ATSAgent()
    body.register_agent(work_type=ATS_WORK_TYPE, handler=ats.process_work)
    body.register_agent(capability=ATS_ANALYZE_CAPABILITY, handler=ats.process_work)
    body.register_agent(agent_id="ats-agent", handler=ats.process_work)
    # Gate G03 (RIS-MO-ADDITION-AGENT-E2E-01): deterministischer math.add-Agent.
    from agents.addition_agent.registry import register_addition_agent
    register_addition_agent(registry, body)
    # RIS-JM-AGENT-STANDARDIZATION-01: deterministic parser agents reusing the
    # shared jobsearch parser library (parse.cv / parse.job).
    from agents.cv_parser_agent.registry import register_cv_parser_agent
    from agents.job_parser_agent.registry import register_job_parser_agent
    register_cv_parser_agent(registry, body)
    register_job_parser_agent(registry, body)
    # RIS-AGENT-ANALYSIS-ORCHESTRATION-04: thin analysis orchestration.
    from agents.analysis_agent.registry import register_analysis_agent
    register_analysis_agent(registry, body, agent=analysis_agent)
    return registry, body


def _parse_record(record: Dict[str, Any]) -> Dict[str, Any]:
    raw = record.get("body", "{}")
    work = json.loads(raw) if isinstance(raw, str) else raw
    if not isinstance(work, dict):
        raise ValueError("SQS body ist kein WorkItem-Objekt")
    return work


def _to_event(work: Dict[str, Any], message_id: Optional[str]) -> Event:
    trigger = str(work.get("trigger_type") or work.get("event_type") or "EVENT").upper()
    if trigger not in {t.value for t in TriggerType}:
        trigger = TriggerType.EVENT.value
    payload = dict(work)
    return Event(
        event_id=message_id or work.get("event_id") or str(uuid.uuid4()),
        event_type=trigger,
        occurred_at=datetime.now(timezone.utc),
        tenant_id=work.get("tenantId") or work.get("tenant_id") or "",
        order_id=work.get("orderId") or work.get("order_id"),
        payload=payload,
        metadata={"messageId": message_id} if message_id else {},
        agent_id=work.get("agentId") or work.get("agent_id"),
    )


class _ConditionalFailed(Exception):
    """Lokaler Marker fuer fehlgeschlagenen Conditional Write (Tests)."""


class _RetryClaimLost(Exception):
    """Another delivery won the conditional retry admission."""


def _is_conditional_failed(exc: Exception) -> bool:
    if isinstance(exc, _ConditionalFailed):
        return True
    resp = getattr(exc, "response", None)
    if isinstance(resp, dict):
        code = resp.get("Error", {}).get("Code")
        if code == "ConditionalCheckFailedException":
            return True
        if code == "TransactionCanceledException":
            reasons = resp.get("CancellationReasons") or []
            return any(
                isinstance(reason, dict)
                and reason.get("Code") == "ConditionalCheckFailed"
                for reason in reasons
            )
    return False


def _ddb_transaction_client(table: Any) -> Any:
    """Return a DynamoDB client that does not apply resource marshalling.

    ``boto3.resource('dynamodb').Table(...).meta.client`` carries the
    document transformation and therefore double-wraps DynamoDB JSON
    (``{"workId": {"M": {"S": {"S": "..."}}}}``). The fence transaction
    passes DynamoDB JSON, so it needs a plain low-level client. Injected
    fake clients (tests) have no ``service_model`` and are returned as-is.
    """
    resource_client = getattr(getattr(table, "meta", None), "client", None)
    if resource_client is None:
        return None
    meta = getattr(resource_client, "meta", None)
    if getattr(meta, "service_model", None) is None:
        return resource_client
    import boto3
    return boto3.client("dynamodb", region_name=getattr(meta, "region_name", None))


def _register_processing(
    table: Any,
    work: Dict[str, Any],
    envelope: ProcessingEnvelope,
    agent_id: str,
    fence_table: Any = None,
    require_fence: bool = False,
) -> Tuple[Dict[str, Any], bool]:
    """WorkItem registrieren (Conditional Write) oder Duplikat feststellen.

    Returns (item, is_duplicate). Duplikat -> kein neuer fachlicher Run.
    """
    now = _utcnow()
    # G5 (D2): the requesting user must survive onto the PERSISTED row.
    # The ingress writers set `userId` (and `requestedBy`); work that
    # reaches the worker without a pre-written item is registered here, and
    # this block used to omit the user entirely -- so such items would be
    # invisible to any per-user lookup. `requestedBy` is accepted as a
    # fallback because _create_work writes only that field.
    user_id = work.get("userId") or work.get("requestedBy") or ""
    if require_fence and (not user_id or not work.get("tenantId")):
        raise SubjectFenceUnavailable("verified subject and tenant are required")
    item = {
        "workId": work["workId"],
        "tenantId": work.get("tenantId", ""),
        "userId": user_id,
        "requestedBy": user_id,
        "idempotencyKey": work.get("idempotencyKey", ""),
        "type": work.get("type", ""),
        "capability": work.get("capability", ""),
        "agentId": agent_id,
        # Transport correlation: ORDER_RESULT needs these after execution.
        "apiProfileId": work.get("apiProfileId", ""),
        "partnerApplicationId": work.get("partnerApplicationId", ""),
        "issuer": work.get("issuer", ""),
        "orderId": work.get("orderId", ""),
        "correlationId": work.get("correlationId") or work.get("requestId", ""),
        "transportMessageId": work.get("transportMessageId", ""),
        "processing_id": envelope.processing_id,
        "execution_id": envelope.execution_id or str(uuid.uuid4()),
        "attempt_id": f"{envelope.processing_id}#1",
        "parent_id": envelope.parent_id or work.get("parentWorkId") or "",
        "sequence_no": envelope.sequence,
        "attempt_no": 1,
        "body_id": envelope.body_id or BODY_VERSION,
        "body_version": envelope.body_version or BODY_VERSION,
        "runtime": RUNTIME_LAMBDA,
        "execution_profile": ExecutionProfile.LAMBDA.value,
        "status": "RUNNING",
        "createdAt": now,
        "updatedAt": now,
    }
    if require_fence:
        if fence_table is None:
            raise SubjectFenceUnavailable("subject fence is required")
        client = _ddb_transaction_client(fence_table)
        table_name = getattr(fence_table, "name", None)
        if client is None or not table_name:
            raise SubjectFenceUnavailable("subject fence transaction is unavailable")
        fence_key = subject_fence_key(
            user_id=user_id,
            tenant_id=work.get("tenantId", ""),
            partner_application_id=work.get("partnerApplicationId", ""),
            issuer=work.get("issuer", ""))
        transact_items = [
            {"ConditionCheck": {
                "TableName": table_name,
                "Key": {"workId": {"S": fence_key}},
                "ConditionExpression": "attribute_not_exists(workId)",
            }},
            {"Put": {
                "TableName": table_name,
                "Item": _ddb_client_item(item),
                "ConditionExpression": "attribute_not_exists(workId)",
            }},
        ]
        try:
            client.transact_write_items(TransactItems=transact_items)
            return item, False
        except Exception as exc:
            if not _is_conditional_failed(exc):
                logger.error(
                    "subject fence admission failed: %s table=%s fence_key=%s work_id=%s",
                    repr(exc), table_name, fence_key, item.get("workId"))
                resp = getattr(exc, "response", None)
                if isinstance(resp, dict):
                    logger.error("cancellation=%s", resp.get("CancellationReasons"))
                raise SubjectFenceUnavailable("subject fence admission failed") from exc
            existing = table.get_item(Key={"workId": work["workId"]}).get("Item", {})
            if existing:
                if existing.get("status") not in TERMINAL_DUPLICATE_STATES:
                    assert_fence_clear(
                        fence_table,
                        user_id=user_id,
                        tenant_id=work.get("tenantId", ""),
                        partner_application_id=work.get("partnerApplicationId", ""),
                        issuer=work.get("issuer", ""),
                    )
                return existing, True
            fence = fence_table.get_item(Key={
                "workId": subject_fence_key(
                    user_id=user_id,
                    tenant_id=work.get("tenantId", ""),
                    partner_application_id=work.get("partnerApplicationId", ""),
                    issuer=work.get("issuer", ""))}).get("Item")
            if fence:
                raise SubjectFenceBlocked("subject is fenced by erasure") from exc
            raise SubjectFenceUnavailable("subject fence state is unavailable") from exc
    try:
        table.put_item(
            Item=item,
            ConditionExpression="attribute_not_exists(workId)",
        )
        return item, False
    except Exception as exc:
        if not _is_conditional_failed(exc):
            raise
        existing = table.get_item(Key={"workId": work["workId"]}).get("Item", {})
        return existing, True


def _to_dynamo(value: Any) -> Any:
    """Python-Werte DDB-sicher machen (DDB kennt keine Floats).

    Nur Float -> Decimal; Ints/Strings/IDs/Timestamps bleiben unveraendert.
    Betrifft nur die Persistenz — API-/Result-Contract unberuehrt.
    """
    from decimal import Decimal

    if isinstance(value, float):
        return Decimal(str(value))
    if isinstance(value, dict):
        return {k: _to_dynamo(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_dynamo(v) for v in value]
    return value


def _ddb_client_item(value: Dict[str, Any]) -> Dict[str, Any]:
    """Serialize a Python item for the injected low-level DDB client."""
    from boto3.dynamodb.types import TypeSerializer
    serializer = TypeSerializer()
    return {key: serializer.serialize(item) for key, item in value.items()}


def _final_fence_admission(table: Any, fence_table: Any,
                           work: Dict[str, Any], attempt: int) -> None:
    """Atomically re-check the subject fence immediately before execution."""
    client = _ddb_transaction_client(fence_table)
    table_name = getattr(fence_table, "name", None)
    if client is None or not table_name:
        raise SubjectFenceUnavailable("subject fence transaction is unavailable")
    user_id = work.get("userId") or work.get("requestedBy") or ""
    tenant_id = work.get("tenantId") or ""
    fence_key = subject_fence_key(
        user_id=user_id, tenant_id=tenant_id,
        partner_application_id=work.get("partnerApplicationId", ""),
        issuer=work.get("issuer", ""))
    try:
        client.transact_write_items(TransactItems=[
            {"ConditionCheck": {
                "TableName": table_name,
                "Key": {"workId": {"S": fence_key}},
                "ConditionExpression": "attribute_not_exists(workId)",
            }},
            {"Update": {
                "TableName": table_name,
                "Key": {"workId": {"S": work["workId"]}},
                "UpdateExpression": "SET updatedAt = :updated",
                "ConditionExpression": "#status = :running AND attempt_no = :attempt",
                "ExpressionAttributeNames": {"#status": "status"},
                "ExpressionAttributeValues": _ddb_client_item({
                    ":updated": _utcnow(), ":running": "RUNNING", ":attempt": attempt}),
            }},
        ])
    except Exception as exc:
        if _is_conditional_failed(exc):
            raise SubjectFenceBlocked("subject is fenced or execution lease is stale") from exc
        raise SubjectFenceUnavailable("subject fence admission failed") from exc


def _persist_result(table: Any, work_id: str, attempt: int, result: Dict[str, Any]) -> None:
    table.update_item(
        Key={"workId": work_id},
        UpdateExpression="SET #status = :s, result_reference = :r, #result = :res, updatedAt = :u",
        ExpressionAttributeNames={"#status": "status", "#result": "result"},
        ExpressionAttributeValues={
            ":s": "COMPLETED",
            ":r": f"work:{work_id}:attempt:{attempt}",
            ":res": _to_dynamo(result),
            ":u": _utcnow(),
            ":running": "RUNNING",
            ":attempt": attempt,
        },
        ConditionExpression="#status = :running AND attempt_no = :attempt",
    )


def _persist_failure(table: Any, work_id: str, attempt: int,
                     error: Dict[str, Any], *, terminal: bool = False) -> None:
    table.update_item(
        Key={"workId": work_id},
        UpdateExpression="SET #status = :s, #error = :e, updatedAt = :u",
        ExpressionAttributeNames={"#status": "status", "#error": "error"},
        ExpressionAttributeValues={
            ":s": "DEAD_LETTER" if terminal else "FAILED",
            ":e": _to_dynamo(error), ":u": _utcnow(),
            ":running": "RUNNING", ":attempt": attempt,
        },
        ConditionExpression="#status = :running AND attempt_no = :attempt",
    )


def _claim_queued_work(table: Any, work_id: str) -> Optional[Dict[str, Any]]:
    """Claim a pre-persisted QUEUED WorkItem for its first attempt.

    The dispatch ingress persists QUEUED and enqueues; the worker must turn
    that row into RUNNING exactly once. Returns the updated item or None when
    another delivery won the claim.
    """
    try:
        table.update_item(
            Key={"workId": work_id},
            UpdateExpression=("SET #status = :running, attempt_no = :attempt, "
                              "updatedAt = :u"),
            ExpressionAttributeNames={"#status": "status"},
            ExpressionAttributeValues={
                ":running": "RUNNING", ":attempt": 1, ":u": _utcnow(),
                ":queued": "QUEUED",
            },
            ConditionExpression="#status = :queued",
        )
    except Exception as exc:  # noqa: BLE001 - boundary
        if _is_conditional_failed(exc):
            return None
        raise
    return table.get_item(Key={"workId": work_id}).get("Item")


def _start_retry_attempt(table: Any, existing: Dict[str, Any]) -> Dict[str, Any]:
    """Bestehendes FAILED-Processing als neuer Attempt fortfuehren."""
    attempt = int(existing.get("attempt_no", 1)) + 1
    execution_id = str(uuid.uuid4())
    try:
        table.update_item(
            Key={"workId": existing["workId"]},
        UpdateExpression=(
            "SET #status = :s, attempt_no = :a, execution_id = :e, "
            "attempt_id = :aid, updatedAt = :u REMOVE #error"
        ),
        ExpressionAttributeNames={"#status": "status", "#error": "error"},
            ExpressionAttributeValues={
                ":s": "RUNNING",
                ":a": attempt,
                ":e": execution_id,
                ":aid": f"{existing.get('processing_id', '')}#{attempt}",
                ":u": _utcnow(),
                ":failed": "FAILED",
                ":expectedAttempt": int(existing.get("attempt_no", 1)),
            },
            ConditionExpression="#status = :failed AND attempt_no = :expectedAttempt",
        )
    except Exception as exc:
        if _is_conditional_failed(exc):
            raise _RetryClaimLost from exc
        raise
    resumed = dict(existing)
    resumed.update({"attempt_no": attempt, "execution_id": execution_id, "status": "RUNNING"})
    return resumed


def process_record(
    record: Dict[str, Any],
    table: Any = None,
    registry: Optional[AgentRegistry] = None,
    body: Any = None,
    entitlement_resolver: Any = None,
    health_tracker: Any = None,
    erasure_admission: Any = None,
    subject_fence_table: Any = None,
    require_subject_fence: bool = False,
    result_sender: Optional[Any] = None,
    analysis_agent: Any = None,
) -> Dict[str, Any]:
    """Einen SQS-Record durch den Runtime-Pfad fuehren (Worker-Einstieg).

    Args:
        entitlement_resolver: Entitlement-Quelle fuer den
            Execution-Time-Re-check (Gate 08). None = kein Re-check
            (nur Test-/Harness-Modus, debug-geloggt); Produktion
            injiziert immer einen Resolver (Handler-SQS-Pfad).
        health_tracker: Optionaler HealthTracker (Gate-02 P3). Emittiert
            HEALTH_DEGRADED/HEALTH_RECOVERED an den echten Grenzen der
            Verarbeitung. None = keine Health-Events (best existing
            behaviour). Health-Instrumentierung darf den Work-Pfad NIE
            fehlschlagen; Fehler werden verschluckt.
    """
    work = _parse_record(record)
    validated = WorkItem(work)  # wirft bei fehlenden Pflichtfeldern (keine Registrierung)
    work = validated.to_dict()

    # Gate-02 P3: Health-Events an den echten Grenzen der Verarbeitung.
    # Jede Aufzeichnung ist defensiv gekapselt -- Observability darf den
    # Work-Pfad nicht zum Fehlschlagen bringen.
    def _health(fn_name, *args, **kwargs):
        if health_tracker is None:
            return
        try:
            events = getattr(health_tracker, fn_name)(*args, **kwargs)
            if events:
                try:
                    health_sink.emit(events)
                except Exception:
                    # Emission failure must not break business processing.
                    # Swallow after logging to avoid recursive health events.
                    logger.warning("health sink emission failed; event dropped")
        except Exception as exc:  # pragma: no cover - defensiv
            logger.warning("health instrumentation failed: %s", exc)

    tenant_id = work.get("tenantId")
    work_id = work.get("workId")

    if erasure_admission is not None:
        # The production caller must inject a durable RIS fence. Test harnesses
        # may omit it explicitly; omission never creates a durable claim here.
        erasure_admission(work, "before_registration")

    table = table if table is not None else _resolve_table()
    registry, body = ensure_reference_agent(registry, body,
                                            analysis_agent=analysis_agent)

    hook = EventHook()
    envelope = hook.handle_event(_to_event(work, record.get("messageId")))

    discovery = AgentDiscovery(registry)
    candidates = discovery.find_from_envelope(envelope)
    if not candidates:
        candidates = discovery.find(
            capability=work.get("capability"),
            agent_id=work.get("agentId"),
            status=AgentStatus.ACTIVE,
        )
    pipeline = EligibilityPipeline(registry).check_candidates(candidates, envelope)
    eligible_ids = {c.agent_id for c in pipeline.eligible}
    eligible = [c for c in candidates if c.agent_id in eligible_ids]
    decision = EcosystemRouter(registry=registry).select(eligible)
    if decision is None:
        raise ValueError(
            f"Kein geeigneter Agent (eligible={len(pipeline.eligible)}, "
            f"rejected={len(pipeline.rejected)})"
        )

    item, is_duplicate = _register_processing(
        table, work, envelope, decision.agent_id,
        fence_table=subject_fence_table, require_fence=require_subject_fence)
    if is_duplicate:
        if item.get("status") in ERASURE_SUPPRESSED_STATES:
            logger.info("erasure-suppressed work message (workId=%s)", work["workId"])
            return {
                "workId": work["workId"], "status": item.get("status"),
                "duplicate": True, "suppressed": True,
                "attempt_no": item.get("attempt_no", 1),
            }
        if item.get("status") in TERMINAL_DUPLICATE_STATES:
            logger.info(
                "Duplikat erkannt (workId=%s, status=%s): kein neuer AgentRun",
                work["workId"],
                item.get("status"),
            )
            delivery = None
            failure_delivery = None
            if item.get("status") == "COMPLETED":
                # Crash window between persist and send: re-emit the same
                # deterministic ORDER_RESULT; the Order side de-duplicates.
                delivery = _forward_order_result(
                    table=table,
                    item=item,
                    attempt=int(item.get("attempt_no") or 1),
                    result=item.get("result"),
                    sender=result_sender,
                )
            elif item.get("status") == "DEAD_LETTER":
                # Crash window between terminal failure and send: re-emit the
                # same deterministic ORDER_FAILED.
                failure_delivery = _forward_order_failure(
                    table=table,
                    item=item,
                    attempt=int(item.get("attempt_no") or 1),
                    error=item.get("error") or {"message": "work item failed"},
                    sender=result_sender,
                )
            response = {
                "workId": work["workId"],
                "status": item.get("status"),
                "duplicate": True,
                "attempt_no": item.get("attempt_no", 1),
                "result_reference": item.get("result_reference"),
            }
            if delivery is not None:
                response["order_result_delivery"] = delivery
            if failure_delivery is not None:
                response["order_failure_delivery"] = failure_delivery
            return response
        if item.get("status") == "RUNNING":
            # Another delivery owns the run; do not execute twice.
            return {"workId": work["workId"], "status": "RUNNING",
                    "duplicate": True, "suppressed": True,
                    "attempt_no": item.get("attempt_no", 1)}
        if item.get("status") == "QUEUED":
            claimed = _claim_queued_work(table, work["workId"])
            if claimed is None:
                return {"workId": work["workId"], "status": "RUNNING",
                        "duplicate": True, "suppressed": True,
                        "attempt_no": item.get("attempt_no", 1)}
            item = claimed
        elif item.get("status") != "FAILED":
            raise RuntimeError("WORK_ADMISSION_STATE_UNSAFE")
        try:
            resumed = _start_retry_attempt(table, item)
        except _RetryClaimLost:
            return {"workId": work["workId"], "status": "RUNNING",
                    "duplicate": True, "suppressed": True,
                    "attempt_no": item.get("attempt_no", 1)}
        item = resumed

    attempt = int(item.get("attempt_no", 1))

    # G04: a partner-scoped work item must carry the APIProfile that was
    # verified at the RIS entry point. Missing binding is a permanent denial,
    # not a retry: an absent identity must never fall back to user-wide
    # authorization. Human/user-wide work items carry no partner application
    # and keep the existing (api_profile_id=None) semantics.
    api_profile_id = work.get("apiProfileId") or None
    partner_application_id = work.get("partnerApplicationId") or None
    if partner_application_id and not api_profile_id:
        binding_error = {
            "message": "Partner-scoped work item carries no verified "
                       "apiProfileId",
            "type": "IDENTITY_BINDING_MISSING",
        }
        _persist_failure(table, work["workId"], attempt,
                         binding_error, terminal=True)
        failure_delivery = _forward_order_failure(
            table=table, item=work, attempt=attempt, error=binding_error,
            sender=result_sender)
        logger.warning(
            "worker identity binding DENIED (workId=%s, partnerApplication=%s)",
            work["workId"], partner_application_id)
        return {
            "workId": work["workId"],
            "status": "DEAD_LETTER",
            "duplicate": False,
            "attempt_no": attempt,
            "agent_id": decision.agent_id,
            "denied": True,
            "reason": "api-profile-binding-missing",
            "result_reference": f"work:{work['workId']}:attempt:{attempt}",
            "order_failure_delivery": failure_delivery,
        }

    # Execution-Time-Entitlement-Re-check (Gate 08): SQS ist
    # Aktivierung, keine Autorisierung. Geprueft wird der ENTSCHIEDENE
    # Agent (Registry-Wahrheit) gegen den registrierten Entitlement-
    # Bestand — unmittelbar vor der fachlichen Ausfuehrung.
    if entitlement_resolver is None:
        logger.debug(
            "worker entitlement re-check disabled (no resolver; "
            "workId=%s) — test/harness mode only", work["workId"])
    else:
        from agents.ecosystem.worker_authorization import (
            check_worker_entitlement,
        )
        try:
            auth = check_worker_entitlement(
                user_id=work.get("userId"),
                tenant_id=work.get("tenantId"),
                agent_id=decision.agent_id,
                work_id=work["workId"],
                resolver=entitlement_resolver,
                # Profile context passthrough (P11): None preserves the
                # user-wide behavior exactly; asserted contexts are verified
                # against profile-bound rows (never trusted blindly).
                api_profile_id=api_profile_id,
            )
        except Exception as exc:
            # Transienter Infrastrukturfehler (Store unerreichbar) ist
            # KEIN Denied: FAILED persistieren + Raise -> bestehende
            # Retry-Semantik (SQS-Redelivery -> neuer Attempt). Kein
            # Fail-Open, kein falsches DENIED.
            _health("record_failure",
                    Component.AGENT_EXECUTION,
                    tenant_id=tenant_id,
                    reason=REASON_ENTITLEMENT_UNAVAILABLE,
                    work_id=work_id,
                    agent_id=decision.agent_id,
                    attempt_id=str(attempt))
            _persist_failure(
                table, work["workId"], attempt,
                {"message": f"Entitlement store unreachable: {exc}",
                 "type": type(exc).__name__})
            raise
        if not auth.authorized:
            # Permanent DENIED: kontrolliert beenden (FAILED persistieren,
            # Nachricht konsumieren — KEIN Retry-Loop, KEIN Raise).
            # Ein DENIED ist KEINE Laufzeit-Degradierung: die Ablehnung ist
            # das korrekte Verhalten, kein Ausfall. Deshalb wird hier KEIN
            # HEALTH_DEGRADED emittiert.
            _persist_failure(
                table, work["workId"], attempt,
                {"message": f"Worker entitlement denied [{auth.reason}]",
                 "type": "ENTITLEMENT_DENIED"}, terminal=True)
            failure_delivery = _forward_order_failure(
                table=table, item=work, attempt=attempt,
                error={"message": f"Worker entitlement denied [{auth.reason}]",
                       "type": "ENTITLEMENT_DENIED"},
                sender=result_sender)
            logger.warning(
                "worker entitlement DENIED (workId=%s, agent=%s, reason=%s, "
                "attempt=%s)", work["workId"], decision.agent_id,
                auth.reason, attempt)
            return {
                "workId": work["workId"],
                "status": "DEAD_LETTER",
                "duplicate": False,
                "attempt_no": attempt,
                "agent_id": decision.agent_id,
                "denied": True,
                "reason": auth.reason,
                "result_reference": f"work:{work['workId']}:attempt:{attempt}",
                "order_failure_delivery": failure_delivery,
            }

    current = table.get_item(Key={"workId": work["workId"]}).get("Item")
    if not current or current.get("status") != "RUNNING" or int(current.get("attempt_no", 1)) != attempt:
        return {"workId": work["workId"], "status": current.get("status") if current else "CANCELLED",
                "duplicate": True, "suppressed": True, "attempt_no": attempt}
    if erasure_admission is not None:
        erasure_admission(work, "before_execution")
    if require_subject_fence:
        _final_fence_admission(table, subject_fence_table, work, attempt)

    engine = ExecutionEngine(agent_body=body)
    try:
        result = engine.execute_from_decision(decision, envelope)
    except Exception as exc:
        _health("record_failure",
                Component.AGENT_EXECUTION,
                tenant_id=tenant_id,
                reason=REASON_AGENT_ERROR,
                work_id=work_id,
                agent_id=decision.agent_id,
                attempt_id=str(attempt))
        _persist_failure(
            table,
            work["workId"],
            attempt,
            {"message": str(exc), "type": type(exc).__name__},
        )
        raise

    terminal = False
    delivery = None
    failure_delivery = None
    if not result.get("success", False):
        error = result.get("error", {"message": "Agent meldete Fehler"})
        _health("record_failure",
                Component.AGENT_EXECUTION,
                tenant_id=tenant_id,
                reason=REASON_AGENT_ERROR,
                work_id=work_id,
                agent_id=decision.agent_id,
                attempt_id=str(attempt))
        terminal = isinstance(error, dict) and error.get("type") in PERMANENT_ERROR_CODES
        _persist_failure(table, work["workId"], attempt, error, terminal=terminal)
        if terminal:
            failure_delivery = _forward_order_failure(
                table=table, item=work, attempt=attempt, error=error,
                sender=result_sender)
        if not terminal:
            # Unerwarteter Fehler -> Retry via SQS-Redelivery (neuer Attempt).
            raise RuntimeError(
                f"Agent {decision.agent_id} fehlgeschlagen "
                f"[{error.get('type')}]: {error.get('message')} "
                f"(workId={work['workId']}, attempt={attempt})"
            )
    else:
        _health("record_success",
                Component.AGENT_EXECUTION,
                tenant_id=tenant_id,
                work_id=work_id,
                agent_id=decision.agent_id,
                attempt_id=str(attempt))
        _persist_result(table, work["workId"], attempt, result)
        delivery = _forward_order_result(
            table=table, item=item, attempt=attempt, result=result,
            sender=result_sender)

    response = {
        "workId": work["workId"],
        "status": "COMPLETED" if result.get("success", False) else ("DEAD_LETTER" if terminal else "FAILED"),
        "duplicate": False,
        "attempt_no": attempt,
        "agent_id": decision.agent_id,
        "processing_id": item.get("processing_id"),
        "result_reference": f"work:{work['workId']}:attempt:{attempt}",
        "result": result,
    }
    if delivery is not None:
        response["order_result_delivery"] = delivery
    if failure_delivery is not None:
        response["order_failure_delivery"] = failure_delivery
    return response


def _result_body(stored: Any) -> Any:
    """Unwrap the pipeline's {success,data} envelope exactly once."""
    if isinstance(stored, dict) and "success" in stored and "data" in stored:
        return stored.get("data") or {}
    return stored


def _dispatch_carrier(item: Dict[str, Any]) -> Dict[str, Any]:
    """Minimal dispatch carrier for the existing result_from_work_item mapping."""
    return {
        "messageType": "ORDER_DISPATCH",
        "orderId": item.get("orderId", ""),
        "correlationId": item.get("correlationId", ""),
        "identity": {
            "contextRef": item.get("apiProfileId") or "",
            "tenantId": item.get("tenantId"),
            "apiProfileId": item.get("apiProfileId"),
            "partnerApplicationId": item.get("partnerApplicationId"),
            "issuer": item.get("issuer"),
        },
    }


def _resolve_result_sender() -> Optional[Any]:
    url = os.environ.get("ORDER_RESULT_QUEUE_URL", "").strip()
    arn = os.environ.get("ORDER_RESULT_SECRET_ARN", "").strip()
    if not url or not arn:
        return None
    from agents.transport.order_result_sender import make_sender

    return make_sender(url, arn)


def _record_result_delivery(table: Any, work_id: str, *, status: str,
                            attempt: int,
                            message_id: Optional[str] = None,
                            code: Optional[str] = None,
                            field: str = "orderResultDelivery") -> None:
    """Persist the transport outcome next to the completed work item.

    ``COMPLETED`` only proves that the agent result was persisted. This marker
    makes the difference to "handed to SQS" observable without changing the
    work lifecycle. It is best effort: a marker failure must never turn a
    successful send into a redelivery.
    """
    if table is None or not work_id:
        return
    marker: Dict[str, Any] = {
        "status": status,
        "attempt": int(attempt),
        "updatedAt": datetime.now(timezone.utc).isoformat(),
    }
    if message_id:
        marker["messageId"] = message_id
    if code:
        marker["code"] = code
    try:
        table.update_item(
            Key={"workId": work_id},
            UpdateExpression="SET #delivery = :delivery",
            ExpressionAttributeNames={
                "#delivery": field},
            ExpressionAttributeValues={":delivery": marker},
            ConditionExpression="attribute_exists(workId)",
        )
    except Exception as exc:  # noqa: BLE001 - observability only
        logger.warning(
            "order result delivery marker not persisted: %s",
            type(exc).__name__)


def _forward_order_result(*, table: Any, item: Dict[str, Any], attempt: int,
                          result: Any,
                          sender: Optional[Any] = None) -> str:
    """Forward a completed order work item via Transport V1, fail-closed.

    Returns the delivery outcome: ``SENT``, ``NOT_CONFIGURED``, ``SKIPPED``
    or ``REJECTED``. Only a sender exception is re-raised (SQS redelivery).
    """
    work_id = item.get("workId", "")
    if not item.get("orderId"):
        return "NOT_ORDER"
    if not item.get("correlationId"):
        logger.warning("order result not forwarded: missing correlationId")
        _record_result_delivery(table, work_id, status="SKIPPED",
                                attempt=attempt, code="missing_correlation")
        return "SKIPPED"
    if not item.get("apiProfileId"):
        logger.warning("order result not forwarded: missing apiProfileId")
        _record_result_delivery(table, work_id, status="SKIPPED",
                                attempt=attempt, code="missing_api_profile")
        return "SKIPPED"
    sender = sender if sender is not None else _resolve_result_sender()
    if sender is None:
        logger.warning(
            "order result not forwarded: result transport not configured")
        _record_result_delivery(table, work_id, status="NOT_CONFIGURED",
                                attempt=attempt, code="transport_not_configured")
        return "NOT_CONFIGURED"
    body = _result_body(result)
    if not isinstance(body, dict):
        logger.warning("order result not forwarded: result body is not an object")
        _record_result_delivery(table, work_id, status="REJECTED",
                                attempt=attempt, code="invalid_result")
        return "REJECTED"
    from agents.transport import (
        ORDER_RESULT,
        TransportError,
        result_from_work_item,
        validate_envelope,
    )

    try:
        envelope = result_from_work_item(
            _dispatch_carrier(item),
            {"workId": item["workId"], "status": "COMPLETED",
             "attempt_no": attempt, "result": body},
        )
        validate_envelope(envelope, expected_type=ORDER_RESULT)
    except TransportError as exc:
        code = getattr(exc, "code", "transport")
        logger.error("order result not forwarded: %s", code)
        _record_result_delivery(table, work_id, status="REJECTED",
                                attempt=attempt, code=code)
        return "REJECTED"
    try:
        sender(envelope)
    except Exception as exc:
        _record_result_delivery(table, work_id, status="RETRYING",
                                attempt=attempt,
                                message_id=envelope.get("messageId"),
                                code=type(exc).__name__)
        raise
    _record_result_delivery(table, work_id, status="SENT", attempt=attempt,
                            message_id=envelope.get("messageId"))
    return "SENT"


def _forward_order_failure(*, table: Any, item: Dict[str, Any], attempt: int,
                           error: Any,
                           sender: Optional[Any] = None) -> str:
    """Forward a terminal order failure as the existing ORDER_FAILED type.

    Returns ``SENT``, ``NOT_ORDER``, ``NOT_CONFIGURED``, ``SKIPPED`` or
    ``REJECTED``. Only a sender exception is re-raised (SQS redelivery).
    The error is reduced to the persisted failure fields; no payload or secret
    is copied into the envelope.
    """
    work_id = item.get("workId", "")
    if not item.get("orderId"):
        return "NOT_ORDER"
    if not item.get("correlationId"):
        logger.warning("order failure not forwarded: missing correlationId")
        _record_result_delivery(table, work_id, status="SKIPPED",
                                attempt=attempt, code="missing_correlation",
                                field="orderFailureDelivery")
        return "SKIPPED"
    if not item.get("apiProfileId"):
        logger.warning("order failure not forwarded: missing apiProfileId")
        _record_result_delivery(table, work_id, status="SKIPPED",
                                attempt=attempt, code="missing_api_profile",
                                field="orderFailureDelivery")
        return "SKIPPED"
    sender = sender if sender is not None else _resolve_result_sender()
    if sender is None:
        logger.warning(
            "order failure not forwarded: result transport not configured")
        _record_result_delivery(table, work_id, status="NOT_CONFIGURED",
                                attempt=attempt, code="transport_not_configured",
                                field="orderFailureDelivery")
        return "NOT_CONFIGURED"

    from agents.transport import ORDER_FAILED, TransportError, result_from_work_item

    safe_error = error if isinstance(error, dict) else {"message": str(error)}
    safe_error = {
        "message": str(safe_error.get("message") or "work item failed")[:500],
        "type": str(safe_error.get("type") or "RuntimeError")[:100],
    }
    try:
        envelope = result_from_work_item(
            _dispatch_carrier(item),
            {"workId": work_id, "status": "FAILED",
             "attempt_no": attempt, "error": safe_error},
            message_type=ORDER_FAILED,
        )
    except TransportError as exc:
        code = getattr(exc, "code", "transport")
        logger.error("order failure not forwarded: %s", code)
        _record_result_delivery(table, work_id, status="REJECTED",
                                attempt=attempt, code=code,
                                field="orderFailureDelivery")
        return "REJECTED"
    try:
        sender(envelope)
    except Exception as exc:
        _record_result_delivery(
            table, work_id, status="RETRYING", attempt=attempt,
            message_id=envelope.get("messageId"),
            code=type(exc).__name__, field="orderFailureDelivery")
        raise
    _record_result_delivery(
        table, work_id, status="SENT", attempt=attempt,
        message_id=envelope.get("messageId"), field="orderFailureDelivery")
    return "SENT"


def _resolve_table() -> Any:  # pragma: no cover - live Pfad (Env), Tests injizieren Fake
    import os

    import boto3

    name = os.environ.get("WORK_ITEMS_TABLE", "mays-ris-dev-work-items")
    return boto3.resource("dynamodb", region_name=os.environ.get("AWS_REGION", "eu-central-1")).Table(name)


__all__ = [
    "process_record",
    "ensure_reference_agent",
    "REFERENCE_AGENT_ID",
    "REFERENCE_CAPABILITY",
]
