# Mays-RIS API Standard — Plattform-Anwendung (konsolidiert)

Meta-Standard (Format-, Versions-, Fehler-Regeln): `API_DOCUMENTATION_STANDARD.md`
(gilt weiter). Diese Datei wendet ihn auf die live Plattform an.

**Vertrag:** Alle Routen, Auth-Typen, Request-/Response-Felder und Statuscodes
in diesem Dokument sind aus drei Quellen abgeglichen — Terraform
(`terraform/modules/api/main.tf`, `terraform/modules/orders_reader/main.tf`),
Handler-Dispatch (`lambda/handler.py`, `lambda/orders_reader.py`) und den
Tests. Nicht abgeglichenes wird als **OPEN** markiert, nicht behauptet.
Konsistenz wird von `tests/test_p20_api_contract_consistency.py` geprüft.

- Stand: 2026-10-05, verifiziert gegen Gateway `aboqolpm0f` (28 Routen live)
- Basis-API-ID: `aboqolpm0f`, Stage `$default`, Region `eu-central-1`
- Basis-URL: `https://aboqolpm0f.execute-api.eu-central-1.amazonaws.com`
  (Stage `$default` ⇒ **kein** Stage-Pfad in der URL)

## 1. Authentifizierung und Autorisierung, 28 Routen

**Cognito ist die Managed Authentication Boundary der Plattform.** Jede
geschützte Route — auch die Machine-Route — verlangt ein gültiges Cognito-JWT,
das API Gateway **vor** dem Lambda prüft. Cognito beantwortet: *ist dieser
Aufrufer authentifiziert und darf er diese geschützte RIS-API erreichen?*

APIProfile, Credential und Entitlement beantworten danach eine zweite, rein
produktbezogene Frage: *welchen zusätzlichen Produkt-/Machine-Kontext darf
dieser bereits authentifizierte Aufrufer verwenden?*

| Autorisierungstyp | Anzahl | Bedeutung |
|---|---|---|
| `JWT` | 35 | Cognito JWT in `Authorization`, geprüft vom Gateway-Authorizer |
| `NONE` | 0 | keine unauthentifizierten Routen mehr |

Zwei Lambda-Backends:

| Backend | Routen | Zweck |
|---|---|---|
| `agent` (`mays-ris-dev-agent`) | 24 | Identity, Profile, Dokumente, Agents, APIProfiles, Credentials, Introspection, Machine |
| `orders-reader` (`mays-ris-dev-orders-reader`) | 4 | `/orders*`, read-mostly |

### 1.1 Zwei Credentials auf der Machine-Route

`POST /v1/m2m/agents/{agentId}/execute` ist JWT-geschützt **und** verlangt
zusätzlich die opake Produkt-Credential. Beide sind Pflicht; keine ersetzt die
andere:

| Header | Inhalt | Geprüft von |
|---|---|---|
| `Authorization: Bearer <JWT>` | Cognito-JWT | API Gateway, **vor** dem Lambda |
| `X-Api-Credential: <ris_…>` | opake Machine-Credential | Lambda via `verify_api_credential()` |

Ein einzelnes `Authorization`-Header kann nicht beides tragen: ein JWT hat drei
punkt-getrennte Segmente, das opake Secret keines. Der Credential-Verkehrweg
ist deshalb ein eigener Header — **keine neue Credential-Technik**: gleiches
Secret, gleicher Digest-Store, gleicher Verifier. Die opake Credential ist
weder entfernt noch durch Cognito ersetzt.

## 2. Plattform-Routen (agent)

| Route | Auth | Erfolg | Weitere Codes |
|---|---|---|---|
| `GET /health` | JWT | 200 | 401 (unauthentifiziert) |
| `GET /platform` | JWT | 200 | — |
| `GET /me` | JWT | 200 | — |
| `GET /me/profile` | JWT | 200 | 404 (kein Profil) |
| `POST /me/profile` | JWT | 201 | 409 (existiert), 400 (kein JSON) |
| `PUT /me/profile` | JWT | 200 | 400 (kein v1-Feld), 404 (kein Upsert) |
| `DELETE /me/profile` | JWT | 204 | 401 (unauthentifiziert), 404 (kein Profil), 500 (Store) |
| `POST /me/documents` | JWT | 200 (Presigned PUT) | 400, 500 |
| `GET /me/documents/{docId}` | JWT | 200 (Presigned GET) | 400, 404, 500 |
| `DELETE /me/documents/{docId}` | JWT | 200 | 400, 404, 500 |
| `GET /agents` | JWT | 200 | — |
| `POST /me/erasure` | JWT | 200, 207 (partial) | 401, 500, 503 |
| `GET /v1/introspection` | JWT | 200 | 401, 404, 503 |
| `GET /v1/offers` | JWT | 200 | 401, 503 |
| `POST /v1/offers` | JWT | 201 | 400, 401, 403, 409, 503 |
| `GET /v1/offers/{offerId}` | JWT | 200 | 401, 404, 503 |
| `PATCH /v1/offers/{offerId}` | JWT | 200 | 400, 401, 403, 404, 503 |
| `POST /v1/offers/{offerId}/status` | JWT | 200 | 400, 401, 403, 404, 503 |
| `POST /v1/offers/{offerId}/grant` | JWT | 200 | 400, 401, 403, 404, 409, 503 |
| `POST /v1/offers/{offerId}/withdraw` | JWT | 200 | 400, 401, 403, 404, 503 |
| `POST /v1/apiprofiles` | JWT | 201 | 400, 403, 409 |
| `GET /v1/apiprofiles` | JWT | 200 | — |
| `GET /v1/apiprofiles/{apiProfileId}` | JWT | 200 | 403, 404 |
| `PATCH /v1/apiprofiles/{apiProfileId}` | JWT | 200 | 400, 403, 404 |
| `POST /v1/apiprofiles/{apiProfileId}/status` | JWT | 200 | 400, 403, 404, 409 |
| `POST /v1/apiprofiles/{apiProfileId}/credentials` | JWT | 201 (200 bei Idempotenz-Wiederholung) | 400, 403, 404, 409 |
| `GET /v1/apiprofiles/{apiProfileId}/credentials` | JWT | 200 | 400, 403, 404 |
| `GET /v1/apiprofiles/{apiProfileId}/credentials/{credentialId}` | JWT | 200 | 400, 403, 404 |
| `POST /v1/apiprofiles/{apiProfileId}/credentials/{credentialId}/rotate` | JWT | 201 (200 bei Wiederholung) | 400, 403, 404, 409 |
| `POST /v1/apiprofiles/{apiProfileId}/credentials/{credentialId}/disable` | JWT | 200 | 403, 404, 409 |
| `POST /v1/apiprofiles/{apiProfileId}/credentials/{credentialId}/enable` | JWT | 200 | 403, 404, 409 |
| `POST /v1/apiprofiles/{apiProfileId}/credentials/{credentialId}/revoke` | JWT | 200 | 403, 404, 409 |

### 2.1 Machine API

| Route | Auth | Erfolg | Weitere Codes |
|---|---|---|---|
| `POST /v1/m2m/agents/{agentId}/execute` | JWT **+** `X-Api-Credential` | 202 | 401, 403, 500, 503 |

Request-Body (alle Felder optional):
`{"capability": string, "payload": object, "idempotencyKey": string}`

Antwort 202: `{"workId": string, "status": string, "requestId": string}`

`202` heißt **nicht** „fertig", sondern „WorkItem angelegt und eingereiht".

**Reihenfolge der Prüfungen:**

1. API Gateway validiert das Cognito-JWT. Fehlt oder ist es ungültig, wird der
   Request **vor** dem Lambda mit 401 abgewiesen.
2. Der Lambda verlangt eine Cognito-Identität (`sub`). Fehlt sie — etwa bei
   direktem Aufruf ohne Gateway — folgt 401. Es gibt keinen anonymen
   Machine-User.
3. `X-Api-Credential` wird gelesen; ohne verwertbaren Wert folgt 401.
4. `verify_api_credential()` prüft Credential → APIProfile → Status → Ablauf →
   Entitlement → Agent-Status. Erst danach wird enqueued.

**Statuscodes der Produkt-Prüfung (nach bestandenem Cognito):**
- **401** — Credential unbekannt, ungültig, fehlend oder fehlerhaft.
- **403** — Credential bekannt, aber unbenutzbar: disabled, revoked,
  abgelaufen, Profil nicht `ACTIVE`, Tenant-/Owner-Mismatch, kein Entitlement,
  Agent nicht ausführbar.
- **503** — Store-/Infrastrukturfehler. **Niemals** 401/403: ein nicht
  erreichbarer Store darf nicht als schlechtes Credential gemeldet werden.

**Identity Binding:** Die Cognito-Identität wird für Audit und Korrelation
erfasst, wählt aber **nie** die ausführende Identität. Diese bleibt der Owner
des APIProfile, zu dem die Credential gehört (`verify_api_credential`). Ein
Request-Body oder -Header kann daher nicht bestimmen, in wessen Kontext
ausgeführt wird, und `agentId` stammt ausschließlich aus dem Route-Path.

### 2.2 Credential Management

Rollen sind aus den Cognito-Gruppen abgeleitet, nicht aus einem Rollen-Claim:

| Rolle | Quelle | Rechte |
|---|---|---|
| `owner` | kein Match | nur eigene Profile/Credentials |
| `staff` | Gruppe `Staff` | Support mit `reason`; **darf nicht anlegen, nicht revoken, nicht ausstellen** |
| `admin` | Gruppe `admins` | tenant-scoped; cross-tenant nur mit `reason` |

Header:

| Header | Wirkung |
|---|---|
| `X-Api-Profile` | Auswahlhinweis; **untrusted** — wird gegen den verifizierten Kontext geprüft. Abweichung ⇒ 400 `Profile mismatch` |
| `Idempotency-Key` | bei `POST` Issue und Rotate; ≤ 128 Zeichen, nicht leer. Wiederholung ⇒ 200 + `"duplicate": true` statt 201 |
| `X-Correlation-Id` | Korrelation; Fallback auf Gateway-`requestId` |

Body-Felder:

| Route | Erlaubte Felder | Pflicht |
|---|---|---|
| `POST /v1/apiprofiles` | `name`, `description`, `targetOwner`, `reason` | `name` |
| `PATCH /v1/apiprofiles/{apiProfileId}` | `name`, `description`, `reason` | — |
| `POST /v1/apiprofiles/{apiProfileId}/status` | `status`, `reason` | `status` |
| `POST /v1/apiprofiles/{apiProfileId}/credentials` | `label`, `expiresAt`, `clientRef`, `reason` | `expiresAt` |
| `POST /v1/apiprofiles/{apiProfileId}/credentials/{credentialId}/rotate` | `expiresAt`, `label`, `reason` | `expiresAt` |
| `POST /v1/apiprofiles/{apiProfileId}/credentials/{credentialId}/disable` | `reason` | — (Staff nur mit `reason`) |
| `POST /v1/apiprofiles/{apiProfileId}/credentials/{credentialId}/enable` | `reason` | — |
| `POST /v1/apiprofiles/{apiProfileId}/credentials/{credentialId}/revoke` | `reason` | — (admin-only) |

Unbekannte Felder ⇒ **400** `Unknown fields: …`. Absichtlich *nicht* akzeptiert:
`clientRef`/`expiresAt` beim Anlegen eines Profils durch den Owner (nur Admin).

Credential-Metadaten (Antwort, 20 Felder): `credentialId`, `apiProfileId`,
`ownerUserId`, `tenantId`, `label`, `credentialType`, `status`, `clientRef`,
`createdAt`, `updatedAt`, `expiresAt`, `lastUsedAt`, `revokedAt`, `revokedBy`,
`revokeReason`, `disabledBy`, `rotationOf`, `idempotencyKey`, `createdBy` —
plus `digest` und `secret` **nur** beim Ausstellen/Rotieren. `digest` und
`secret` verlassen den Store nie (`_public_metadata` entfernt `digest`).

Credential-Lifecycle: `ACTIVE ⇄ DISABLED → REVOKED`, `REVOKED` ist terminal
(Reaktivierung ⇒ 409). Rotation revokiert das alte und legt ein neues `ACTIVE`
an (`rotationOf` verknüpft).

APIProfile-Lifecycle: `PENDING → ACTIVE | DISABLED | REVOKED`,
`ACTIVE ⇄ DISABLED`, `REVOKED` terminal. Aktivierung und Revoke sind
**admin-only**.

### 2.3 Introspection

`GET /v1/introspection` ist read-only und gibt die auflösbaren Fähigkeiten des
Aufrufers zurück. Pflicht-Keys in **jedem** Kontext: `context`, `subject`
(`userId`, `tenantId`), `capabilities`, `validity.checkedAt`, `resolution`
(`selectedBy`, `resolvedAt`, `request`). Im Kontext `profile` zusätzlich
`profile` (`apiProfileId`, `name`, `status`, `clientRef`, `expiresAt`,
`offerRefs`), `offers`, `validity.profileExpiresAt`; je Fähigkeit
`capabilities[]` mit `scopeRestricted` und `expiresHint`.

Kontextwahl: `context` ist `human` ohne `X-Api-Profile`, sonst `profile` bzw.
`credential`.

### 2.4 Offer-Administration (Product Admin)

Offer ist das RIS-Produktobjekt: ein admin-eigenes Paket aus Agent-Zuordnungen.
Ein Grant erzeugt daraus **eine Entitlement-Zeile je Offer-Agent**, atomar
(alles oder nichts), idempotent und ohne stilles Zusammenführen.

Rollen: nur die Cognito-Gruppe `admins` darf Offers definieren und Grants
ausführen. `Staff` darf Offers **lesen** (nur `ACTIVE`, als Display-Info), aber
nicht definieren. Eigentümer/User haben keinen Schreibpfad. `admins` ist eine
Produktrolle und gewährt **keine** AWS-Rechte.

| Route | Body-Felder | Pflicht |
|---|---|---|
| `POST /v1/offers` | `name`, `description`, `agentIds`, `status` | `name`, `agentIds` |
| `PATCH /v1/offers/{offerId}` | `agentIds`, `description` | — |
| `POST /v1/offers/{offerId}/status` | `status`, `reason` | beide |
| `POST /v1/offers/{offerId}/grant` | `userId`, `tenantId`, `reason`, `validFrom`, `validUntil` | alle fünf |
| `POST /v1/offers/{offerId}/withdraw` | `entitlementId`, `reason` | beide |

`status` ist `ACTIVE` oder `INACTIVE`. `agentIds` müssen **alle** im Agent
Catalog existieren und ausführbar sein, sonst wird nichts persistiert (kein
Teilwrite). `reason` ist bei Statuswechsel, Grant und Entzug Pflicht.

Der Grant-Modus dieses Gates ist **user-wide**: die Zeilen entstehen ohne
`apiProfileId`. Das ist die Form, die `check_worker_entitlement` als
user-weit behandelt. Ein profilgebundener Grant bleibt in der Domäne möglich,
wird hier aber nicht genutzt.

Agent-Änderungen an einem Offer wirken nur auf **künftige** Grants. Ebenso
blockiert ein `INACTIVE`-Offer nur künftige Grants — bestehende Entitlements
bleiben bis Ablauf oder Entzug gültig (keine Rückwirkung).

Fehlerbilanz: 400 Validierung/Grant-Ablehnung, 401 kein JWT, 403 nicht-Admin,
404 Offer/Entitlement unbekannt, 409 Namens- oder Idempotenzkonflikt, 503 Stores
nicht konfiguriert.

## 3. Orders-Routen (orders-reader)

| Route | Auth | Erfolg | Weitere Codes |
|---|---|---|---|
| `GET /orders` | JWT | 200 | 400 (`limit` nicht Integer oder nicht 1..100) |
| `GET /orders/{orderId}` | JWT | 200 | 400, 404 `ORDER_NOT_FOUND` |
| `POST /orders` | JWT | 201 (`PENDING` + SQS-Anstoß) | 400, 500 |
| `PATCH /orders/{orderId}/status` | JWT | 200 | 400, 404, 409 (`INVALID_TRANSITION`, `CONFLICT`) |

`GET /orders` Antwort: `{"orders": [...], "count": number}`, Query-Parameter
`limit` (Default 20, 1..100).

Statuswerte: `PENDING`, `CONFIRMED`, `PROCESSING`, `SHIPPED`, `DELIVERED`,
`CANCELLED`. Übergänge: `PENDING→{CONFIRMED,CANCELLED}`,
`CONFIRMED→{PROCESSING,CANCELLED}`, `PROCESSING→{SHIPPED}`, `SHIPPED→{DELIVERED}`;
`DELIVERED` und `CANCELLED` sind Endzustände.

## 4. Fehlerformat — zwei Formen, ehrlich benannt

Das ist die wichtigste Korrektur gegenüber der alten Fassung.

| Backend | Fehlerformat |
|---|---|
| `orders-reader` | `{"error": {"code": string, "message": string, "details"?: object}}` |
| `agent` | `{"error": "<string>"}` |

Der `agent`-Pfad nutzt durchgängig String-Fehler, z. B.
`{"error": "Not found"}`, `{"error": "Forbidden"}`,
`{"error": "Temporarily unavailable"}`. Codes wie `VALIDATION_ERROR` oder
`ORDER_NOT_FOUND` existieren **nur** im orders-reader-Pfad.

Codes live belegt (orders-reader): `VALIDATION_ERROR` (400),
`ORDER_NOT_FOUND` (404), `INVALID_TRANSITION` (409), `CONFLICT` (409),
`INTERNAL_ERROR` (500).

Die Meta-Standard-Form `{"error":{"code","message"}}` ist damit **nicht**
plattformweit erfüllt. Das ist eine bewusst dokumentierte Abweichung
(siehe §8, OPEN-2), keine Behauptung.

Gateway-eigene Fehler (401/404 bei fehlendem Token bzw. unbekannter Route)
stammen von API Gateway, nicht vom Handler: `{"message": "Unauthorized"}` /
`{"message": "Not Found"}`.

Statuscode-Konventionen im `agent`-Pfad:

| Code | Bedeutung | Quellcode |
|---|---|---|
| 400 | unbekanntes/fehlendes Feld, ungültiges JSON, Header-Konflikt | `_aprof_fail`, `_cred_fail`, `_aprof_body`, `_cred_body` |
| 401 | kein `userId` im JWT (nur bei JWT-Routen) | `_extract_user_context` |
| 403 | Rolle/Status/Tenant verbietet die Aktion | `_aprof_fail`, `_cred_fail` |
| 404 | fehlend **oder** fremd (neutral, kein Oracle) | `_aprof_fail`, `_cred_fail` |
| 409 | Konflikt, ungültige Transition, Store-Ausfall als Konflikt | `_aprof_fail`, `_cred_fail` |
| 503 | Store nicht konfiguriert/nicht erreichbar | `_aprof_store`, `_cred_sources`, `_machine_bearer`-Umfeld |
| 500 | unerwartet, ohne Stacktrace nach außen | `logger.exception` + neutraler Text |

Der neutrale 404 ist Absicht: für `owner` sind „fremd" und „existiert nicht"
nicht unterscheidbar. Für `admin`/`staff` liefert derselbe Fall 403.

## 5. Auth / Claims

`Authorization: Bearer <JWT>` aus Cognito-User-Pool `users`. Claims in Nutzung:
`sub` (userId), `email`, `preferred_username`, `cognito:groups`,
`custom:tenant_id`. Der JWT-Authorizer prüft `issuer` und `audience`; eine
Scope-Prüfung findet **nicht** statt — Autorisierung erfolgt im Handler über
`cognito:groups`.

Dies gilt für alle 27 JWT-Routen einschließlich der Machine-Route: der
JWT-Authorizer ist derselbe, und es existiert kein Pfad, der Cognito umgeht.

Keine Signup-/Login-Routen im Repo; der User Pool erlaubt Self-Service-SignUp,
der Bestätigungsversand ist AWS-managed (Inbox-Eingabe nicht als PROVEN geführt).

Registrierung: SignUp → Confirm (E-Mail-Code) → Login (USER_PASSWORD_AUTH) →
JWT → `POST /me/profile` (Conditional Write, 409 bei Duplikat) → `GET /me/profile`.
**Niemals** Auto-Provisioning durch Reads.

## 6. Verbindliche Semantik

Synchroner API-Aufruf ≠ WorkItem ≠ Agent Run ≠ Attempt. Eine POST-Antwort
bedeutet **nicht** Verarbeitung, nur Registrierung plus Queue-Anstoß.

`/health` ist bewusst abhängigkeitsfrei (kein DynamoDB-, Cognito- oder
SQS-Zugriff). Ein Probe-Aufruf, der an einer Abhängigkeit hängt, würde das
Target während eines Ausfalls der Abhängigkeit als ungesund melden, obwohl die
Lambda startfähig ist. Abhängigkeits-Erreichbarkeit meldet `GET /platform`
(JWT-geschützt), nicht der Liveness-Probe.

## 7. Idempotency / Pagination / Filter

- **HTTP-Idempotency:** implementiert für Credential-Ausstellen und -Rotation
  (`Idempotency-Key`, siehe §2.2). **Nicht** implementiert für `POST /orders`,
  `POST /me/profile` (dort via Conditional Write → 409) und die Status-Aktionen.
- **Pagination:** `limit` (1..100, Default 20) auf `GET /orders`. Es gibt
  **keine** `nextToken`-Mechanik: im orders-reader-Code existiert weder
  `nextToken` noch `LastEvaluatedKey`. Die frühere Fassung dieses Dokuments
  behauptete das Gegenteil; die Behauptung war falsch (OPEN-4).
- **Filter:** `status` wird auf `PATCH /orders/{orderId}/status` als
  Zielfeld akzeptiert, nicht als Listenfilter. Weitere Filter existieren nicht.

## 8. Abweichungen und OPENs (nicht heimlich korrigiert)

- **OPEN-1 — GESCHLOSSEN (G4-PLATFORM-OPENAPI-CONTRACT-01).** Der
  maschinenlesbare Plattform-Vertrag liegt jetzt in
  **`docs/api/openapi-platform.yaml`** (OpenAPI 3.0.3, 36 Operationen =
  33 Terraform-Routen + 3 OPEN-3-Dokumentrouten).
  `jobsearch/openapi.yaml` bleibt unverändert — es beschreibt einen externen
  Dienst (`/v1/jobs/*`), keine Plattform-Route.
  Das Dokument wird von `tests/test_platform_openapi_contract.py` gegen
  Terraform **und** den Dispatcher geprüft; Drift bricht den Test.
- **Route-Identität ist (METHOD, PATH)** (Gate-02 P2B). Eine exposierte Route
  gilt **nur** für ihre Methode. `GET /me/profile` deckt `DELETE /me/profile`
  nicht ab. Maßgeblich ist die Terraform-Deklaration bzw. die Gateway-Route,
  nicht die Existenz eines Handler-Zweigs. Ein Handler ohne Gateway-Route ist
  toter Code, keine API.
- **OPEN-2 — Fehlerformat uneinheitlich.** `orders-reader` nutzt
  `{"error":{"code","message"}}`, `agent` nutzt `{"error":"<string>"}` (§4).
  Vereinheitlichen wäre ein API-Redesign und ist ausdrücklich nicht Teil dieses
  Gates.
- **OPEN-3 — Drei Routen ohne Terraform-Definition.** `POST /me/documents`,
  `GET /me/documents/{docId}` und `DELETE /me/documents/{docId}` sind live im
  Gateway, aber in **keiner** `.tf`-Datei des Repos deklariert; sie sind
  imperative Altlasten. Ein `terraform apply` verwaltet sie nicht, und ihre
  Löschung ist nicht durch Terraform abgesichert. Sie sind hier dokumentiert,
  weil sie live sind — eine Aufnahme in `terraform/modules/api` wäre eine
  eigene Änderung und wird hier **nicht** vorgenommen.
- **OPEN-4 — Keine `nextToken`-Pagination** (§7).
- **OPEN-5 — Handler-Zweige ohne Gateway-Route.** `_handle_api_event` bedient
  `/api/agents*`, `/work*` und `/me/jobsearches*`, für die es **keine**
  Gateway-Route gibt. Live liefern diese Pfade 404. Der Code ist vorhanden, der
  Zugang nicht exponiert; hier wird keine Route ergänzt.
- **OPEN-6 — `_handle_introspection` trägt einen veralteten Docstring**
  (`lambda/handler.py:959`: „NOT routed from API Gateway yet"). Die Route
  existiert seit P13 live. Nur der Kommentar war falsch.
- **Kein CI-Gate.** Die Pipeline prüft ausschließlich Terraform; weder `pytest`
  noch ein Linter laufen dort. Die Konsistenzprüfung aus
  `tests/test_p20_api_contract_consistency.py` schützt daher nur bei
  lokalem Testlauf.

**Vertragsänderung P21-01 (bewusst):** Die Machine-Route war bis P21-01
`AuthorizationType NONE` und trug die opake Credential im `Authorization`-Header.
Sie ist jetzt JWT-geschützt und erwartet die opake Credential in
`X-Api-Credential`. Machine-Clients, die bisher nur ein `ris_…` sendeten,
erhalten ab sofort 401 vom Gateway. Beide Credentials sind Pflicht; die
Architekturentscheidung lautet ausdrücklich: *Cognito bleibt die Managed
Authentication Boundary, APIProfile/Credential/Entitlement liefern zusätzliche
Produkt-/API-Autorisierung innerhalb dieses authentifizierten Kontexts.*

## 9. Herkunft der Angaben

| Angabe | Quelle |
|---|---|
| Route ↔ Auth-Typ ↔ Backend | `aws apigatewayv2 get-routes` (28 live), `terraform/modules/api/main.tf`, `terraform/modules/orders_reader/main.tf` |
| Statuscodes, Fehlertexte, Body-Felder | `lambda/handler.py`, `lambda/orders_reader.py`, `lambda/documents.py` |
| Rollen- und Lifecycle-Regeln | `agents/ecosystem/api_profiles.py`, `agents/ecosystem/credentials.py`, `agents/ecosystem/introspection.py` |
| Orders-Übergänge, `limit` | `lambda/orders_reader.py` |
| Live-Verhalten der Kernrouten | `tests/test_p17_credential_lifecycle.py`, `tests/test_machine_entrypoint.py`, `tests/test_p20_health_contract.py` |
| Offer-Vertrag, Grant, Rollen | `agents/ecosystem/offers.py`, `tests/test_p23_offer_product_admin.py` |